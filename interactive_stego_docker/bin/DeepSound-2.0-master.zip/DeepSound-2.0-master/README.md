# DeepSound-2.0
DeepSound might be used as copyright marking software for wave, flac, wma, ape, and audio CD. DeepSound also support encrypting secret files using AES-256(Advanced Encryption Standard) to improve data protection.

The application additionally contains an easy to use Audio Converter Module that can encode several audio formats (FLAC, MP3, WMA, WAV, APE) to others (FLAC, MP3, WAV, APE). 
